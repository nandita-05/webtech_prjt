# Introduction

I created this E-commerce website based on a current design.

I used HTML, CSS and Vanilla JS.

## How to use

The website is pretty straightforward.

The home, about, and store buttons will take you to the relevant section of the website.

On the store section you can add the different items to the basket, when you do an alert will let you know how many item(s) you have in the basket + the total value.

## Technology I used

I used HTML and CSS, using my own style sheets (no framework).

I used JavaScript for the functionality such as updating the cart when an item is added, clearing the cart when the clear cart button is pressed. I also created a filter method via the buttons on the store page, and also via the searchbar, so the customer can filter through to find the items faster.
